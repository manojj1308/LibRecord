import React from 'react';
import {Container,Row,Col, Input, Button} from 'reactstrap'
import '../Books/books.css'

function Books(){
 return(
   <Container fluid= "lg-12">

       <Row lg="12">
           <div>
           <Input className="searchin" placeholder=" Search"/><Button style={{marginLeft:"500px", marginTop:"10px"}}>Search</Button>
           </div>
       </Row>
         <Row lg="12" className="Notirow">
            <Col lg="3">
            <div>
            <img alt="img1"className="img" src="https://bit.ly/3m3peND"></img>
        </div>
            </Col>
            <Col lg="3">
            <div>
      <img alt="img1"className="img" src="https://bit.ly/31Aa20Q"></img>
      </div>
              
            </Col>
            <Col lg="3">
            <div>
      <img alt="img1"className="img" src="https://bit.ly/3weYDBN"></img>
      </div>
            </Col>
            <Col lg="3">
            <div>
      <img alt="img1"className="img" src="https://bit.ly/3fpcakr"></img>
      </div>
            </Col>
         </Row>

         <Row lg="12" className="Notirow">
            <Col lg="3">
            <div>
            <img alt="img1"className="img" src="https://bit.ly/3weYDBN"></img>
        </div>
            </Col>
            <Col lg="3">
            <div>
      <img alt="img1"className="img" src="https://bit.ly/3fpcakr"></img>
      </div>
              
            </Col>
            <Col lg="3">
            <div>
      <img alt="img1"className="img" src="https://bit.ly/3m3peND"></img>
      </div>
            </Col>
            <Col lg="3">
            <div>
      <img alt="img1"className="img" src="https://bit.ly/31Aa20Q"></img>
      </div>
            </Col>
         </Row>
    </Container>
 )

}
export default Books;