import React from 'react';
import {Container,Button,Row,Col} from 'reactstrap'
import '../Notification/notification.css'

function Notification(){
 return(
   <Container fluid= "lg-12">
         <Row lg="12" className="Notirow">
            <Col lg="6">
                <p>BooK Request From <b>Madhan(1P18MC027)</b><br/> Think And Grow Rich<br/><b>Book Available</b></p>
            </Col>
            <Col lg="6">
                <Button >Accept</Button>
                <Button style={{marginLeft:"10px"}}>Reject</Button>
            </Col>
         </Row>
         <Row lg="12" className="Notirow">
            <Col lg="6">
                <p>BooK Request From <b>Karky(1P18MC020)</b><br/> Objective General English<br/><b>Book Available</b></p>
            </Col>
            <Col lg="6">
                <Button>Accept</Button>
                <Button style={{marginLeft:"10px"}}>Reject</Button>
            </Col>
         </Row>
    </Container>
 )

}
export default Notification;