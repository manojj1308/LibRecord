import React from 'react';
import {Container,Row,Col} from 'reactstrap'
import '../Footer/footer.css'
function footer(){
    return(
        <Container fluid="lg-12">
            <div class="jumbotron">
        <h1 class="display-4">Hello!</h1>
        <p className="Head">For More Information Contact Us On</p>
        <hr class="my-4"></hr>
        <Row>
        <Col lg={6}>
            <div className="part1">
                <span><i class="fa fa-envelope fa-2x" aria-hidden="true"></i><b className="insta">Phone +91 9786543221</b></span>
                <span className="spa1"> <i class="fa fa-facebook-official fa-2x" aria-hidden="true"></i ><b className="insta"> Mail to Librarian@abc</b></span>
          </div>


        </Col>
        <Col lg={6}>
            <div>
            <span><i class="fa fa-instagram fa-2x" aria-hidden="true"></i><b className="insta">Facebook @LibRecord</b></span>
            <span className="spa1"> <i class="fa fa-twitter fa-2x" aria-hidden="true"></i ><b className="insta"> Instagram @LibRecord</b></span>

            </div>
          
          
        </Col>
        </Row>
       </div>
        </Container>
      
    )
}
export default footer;
