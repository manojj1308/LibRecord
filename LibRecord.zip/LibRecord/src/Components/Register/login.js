import React, { Component } from 'react'
// import { login } from '../../../ApiService'
import './login.css'
class Login extends Component {
  constructor() {
    super()
    this.state = {
      id: '',
      password: '',
      errors: {}
    }
    this.onChange = this.onChange.bind(this)
    // this.onSubmit = this.onSubmit.bind(this)
  }
  onChange(e) {
    this.setState({ [e.target.name]: e.target.value })
  }
  // onSubmit(e) {
  //   e.preventDefault()
  //   const user = {
  //     email: this.state.email,
  //     password: this.state.password
  //   }

  //   login(user).then(res => {
  //     if (res) {
  //       this.props.history.push(`/`)
  //       window.location.reload();
  //     }
  //   })
  // }

  render() {
    return (
      <div className="total" style={{height: "610px"}}> 
      <div className="container">
      <div className="card" id="cs1" style={{height: "410px"}} >
        <div className="row">
          <div className="col-md-6 mt-5 mx-auto loginform">
            <form noValidate  onSubmit={this.onSubmit}>
              <h1 className="h3 mb-3 font-weight-normal ltitle"> Login With LibRecord</h1><br/>
              <div className="form-group">
                <label htmlFor="email">Student Id</label>
                <input
                  type="email"
                  className="form-control"
                  name="id"
                  placeholder="Enter Student"
                  value={this.state.email}
                  onChange={this.onChange}
                />
              </div>
              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                  type="password"
                  className="form-control"
                  name="password"
                  placeholder="Enter Password"
                  value={this.state.password}
                  onChange={this.onChange}
                />
              </div>
              <button
                type="submit"
                className="btn btn-lg btn-primary btn-block lbutton"
              >
                Sign in
              </button>
            </form>
          </div>
        </div>
      </div>
      </div>
      </div>
    )
  }
}
export default Login