
import React, { useState } from 'react';
import Slider from "react-slick";
import '../Slick/slick.css'
import { Button, Modal, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Container,
  Input,
  Row,
  Col ,
  Form, 
  FormGroup, 
  Label,
  FormText
} from 'reactstrap';

function Example() {
  const [modal, setModal] = useState(false);
  const [modal1, setModal1] = useState(false)
  const [submit1, setModal2] = useState(false)

  const toggle = () => setModal(!modal); 
  const toggle1 = () => setModal1(!modal1); 
  const subtoggle = () => setModal2(!submit1);



    var settings = {
      dots: true,
      infinite: true,
      autoplay:true,
      speed: 50,
      slidesToShow: 3,
      slidesToScroll: 1
    };

    function alerts(){
        alert('Submission sucessfully')
    }
    return (
      <Container fluid="lg-12">
      <Slider className="slick" {...settings}>
      <div className="firstdiv">
          <div>
            <img alt="img1"className="img" src="https://bit.ly/3m3peND"></img>
        </div>
             <p className="para">Think And Grow Rich</p>
      </div>
       
     

      <div className="firstdiv">
      <div>
      <img alt="img1"className="img" src="https://bit.ly/31Aa20Q"></img>
      </div>
      <div>
        <p className="para"> Objective General English </p>
        </div>
     
      </div>
     
     <div className="firstdiv">
     <div>
      <img alt="img1"className="img" src="https://bit.ly/3weYDBN"></img>
      </div>
      <div>
        <p className="para"> Sapiens </p>
      </div>
     </div>
     
     <div className="firstdiv">
     <div>
      <img alt="img1"className="img" src="https://bit.ly/3fpcakr"></img>
      </div>
      <div>
        <p  className="para">Night Sky Playing Cards</p>
      </div>
     </div>

    <div className="firstdiv">
    <div>
      <img alt="img1"className="img" src="https://bit.ly/31ylxWW"></img>
      </div>
      <div>
      <p  className="para">Voice and the Actor</p>
      </div>
    </div>
    </Slider>






    {/* Model for python */}
    
    <Modal size="lg" isOpen={modal} toggle={toggle} >
        <ModalHeader className="modelhead"  size="lg md sm" toggle={toggle}>Python</ModalHeader>
        <ModalBody size="lg">
        <Row lg={12}>
          <Col lg={6}>
            <img className="modelimg"src="https://bit.ly/3c4Vc7s"></img>
          </Col>
          <Col lg={6}>
            <center><b>About the course</b></center><br/>
          <p className="mpara">Python is an interpreted, high-level and general-purpose programming language. Python's design philosophy emphasizes code 
          readability with its notable use of significant indentation. Its language constructs and object-oriented
           approach aim to help programmers write clear, logical code for small and large-scale projects</p>
           <b>Course Period : 6 months</b> <br/><b>Exam Mode : Online</b>
          </Col>
        </Row>

        </ModalBody>
        <ModalFooter size="lg">
          
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter>
      </Modal>


    {/* Model for Java */}

      <Modal size="lg" isOpen={modal1} toggle={toggle1} >
        <ModalHeader className="modelhead"  size="lg" toggle={toggle}>Java</ModalHeader>
        <ModalBody size="lg">
        <Row lg={12}>
          <Col lg={6}>
            <img className="modelimg"src="https://bit.ly/3uSAtwd"></img>
          </Col>
          <Col lg={6}>
            <center><b>About the course</b></center><br/>
          <p className="mpara">Java is a class-based, object-oriented programming language that is designed to have
           as few implementation dependencies as possible. It is a general-purpose programming language 
           intended to let application developers write once, run anywhere (WORA),[17] 
           meaning that compiled Java code can run on all platforms that support Java without the need for recompilation</p>
           <b>Course Period : 6 months</b> <br/><b>Exam Mode : Online</b>
          </Col>
        </Row>

        </ModalBody>
        <ModalFooter size="lg">
          
          <Button color="secondary" onClick={toggle1}>Cancel</Button>
        </ModalFooter>
      </Modal>


      {/* This Model for Course Submission */}

      <Modal isOpen={submit1} toggle={subtoggle} >
      <ModalHeader className="modelhead"  size="lg" toggle={subtoggle}>Apply</ModalHeader>
        <ModalBody size="lg">
        <Form>
      <FormGroup>
        <Label for="exampleEmail">Name</Label>
        <Input type="email" name="name" id="exampleEmail" placeholder="Enter Your Name" />
      </FormGroup>
      <FormGroup>
        <Label for="examplePassword">Password</Label>
        <Input type="password" name="password" id="examplePassword" placeholder="Enter Phone Number" />
      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Schedule Time</Label>
        <Input type="select" name="select" id="exampleSelect">
          <option>Day Time</option>
          <option>Night Time</option>
        </Input>
      </FormGroup>
      <FormGroup>
        <Label for="exampleSelect">Time</Label>
        <Input type="select" name="select" id="exampleSelect">
          <option> 9am - 10am</option>
          <option>11am - 12pm</option>
          <option>8pm - 9pm</option>
          <option>10pm - 11pm</option>
        </Input>
      </FormGroup>
      <Button onClick={alerts}>Submit</Button>
    </Form>
        </ModalBody>
        <ModalFooter size="lg">
          
          <Button color="secondary" onClick={subtoggle}>Cancel</Button>
        </ModalFooter>
      

      </Modal>


    </Container>
    );
}
export default Example;
