import React,{useState} from 'react';
import {Container, Navbar,NavbarBrand,NavbarToggler,Collapse,Nav,NavItem,NavLink,Button} from 'reactstrap'
import '../Navbar/navbar.css'

function  Navs(){
    const [isOpen, setIsOpen] = useState(false);

    const toggle = () => setIsOpen(!isOpen);
 return(
   <Container fluid= "lg-12">
             <Navbar className="nav" color="white" light expand="md">
        <NavbarBrand href="/" className="brand">LibRecord</NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="me-auto" navbar>
          <NavItem className="Navitem">
              <NavLink href="/register" className="item"> Sign Up </NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/login" className="item1"> Login  </NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/Books" className="item1"> Books</NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/Notification" className="item1"> Notification </NavLink>
            </NavItem>
          </Nav>
        </Collapse>
      </Navbar>
    </Container>
 )

}
export default Navs;