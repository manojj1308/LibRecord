import React from 'react';
import './App.css';
import Navs from '../src/Components/Navbar/navbar'
import Slick from '../src/Components/Slick/slick'
import Footer from '../src/Components/Footer/footer'
import Reg from '../src/Components/Login/UserRegister'
import Log from '../src/Components/Register/login'
import Noti from '../src/Components/Notification/Notification'
import Books  from '../src/Components/Books/Books'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'; 
function App() {
  return (
    <div className="App">  
    <Router>
    <Navs/>
    <Switch>
     <Route path='/' exact render={props =>
            <div> 
              <Slick />
            </div>
      }/> 
      <Route  path='/register' component={Reg}/>   
      <Route path = '/login'  component={Log}/>
      <Route path = '/Notification'  component={Noti}/>
      <Route path = '/Books'  component={Books}/>
    </Switch>
    <Footer/>
    </Router>     
    </div>
  );
}

export default App;

